-= SD card boot image =-

Platform: pr_led
Application: top

1. Copy the contents of this directory to an SD card
2. Set boot mode to SD
3. Insert SD card and turn board on
